CREATE DATABASE db_mercado;

USE db_mercado;

