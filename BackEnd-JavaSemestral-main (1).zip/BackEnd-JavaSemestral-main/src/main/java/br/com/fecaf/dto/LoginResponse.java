package br.com.fecaf.dto;

public class LoginResponse {
}
