package br.com.fecaf;

import br.com.fecaf.controller.Menu;

public class Geometria {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.executarMenu();
    }
}
