package br.com.fecaf.repository;

public interface PaymentServiceFake {
}
