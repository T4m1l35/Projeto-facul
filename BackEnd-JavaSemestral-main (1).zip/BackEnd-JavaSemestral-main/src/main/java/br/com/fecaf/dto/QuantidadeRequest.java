package br.com.fecaf.dto;

public class QuantidadeRequest {
    private int quantidade;

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
}