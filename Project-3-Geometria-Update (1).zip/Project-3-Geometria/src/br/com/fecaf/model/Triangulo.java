package br.com.fecaf.model;

public class Triangulo {
}
